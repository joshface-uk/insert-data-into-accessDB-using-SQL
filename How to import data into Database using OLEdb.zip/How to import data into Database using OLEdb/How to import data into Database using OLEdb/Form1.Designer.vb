﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbx_Gender = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbx_Surname = New System.Windows.Forms.TextBox()
        Me.tbx_Forename = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NUD_Age = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NUD_IDNumber = New System.Windows.Forms.NumericUpDown()
        CType(Me.NUD_Age, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_IDNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_Clear
        '
        Me.btn_Clear.Location = New System.Drawing.Point(51, 178)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(105, 26)
        Me.btn_Clear.TabIndex = 23
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(195, 178)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 26)
        Me.Button1.TabIndex = 22
        Me.Button1.Text = "Add"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(60, 154)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Gender:"
        '
        'cbx_Gender
        '
        Me.cbx_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbx_Gender.FormattingEnabled = True
        Me.cbx_Gender.Location = New System.Drawing.Point(111, 151)
        Me.cbx_Gender.Name = "cbx_Gender"
        Me.cbx_Gender.Size = New System.Drawing.Size(189, 21)
        Me.cbx_Gender.TabIndex = 20
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(53, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Surname:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 76)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Forename:"
        '
        'tbx_Surname
        '
        Me.tbx_Surname.Location = New System.Drawing.Point(111, 99)
        Me.tbx_Surname.Name = "tbx_Surname"
        Me.tbx_Surname.Size = New System.Drawing.Size(189, 20)
        Me.tbx_Surname.TabIndex = 17
        '
        'tbx_Forename
        '
        Me.tbx_Forename.Location = New System.Drawing.Point(111, 73)
        Me.tbx_Forename.Name = "tbx_Forename"
        Me.tbx_Forename.Size = New System.Drawing.Size(189, 20)
        Me.tbx_Forename.TabIndex = 16
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(76, 127)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Age:"
        '
        'NUD_Age
        '
        Me.NUD_Age.Location = New System.Drawing.Point(111, 125)
        Me.NUD_Age.Name = "NUD_Age"
        Me.NUD_Age.Size = New System.Drawing.Size(189, 20)
        Me.NUD_Age.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(84, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "ID:"
        '
        'NUD_IDNumber
        '
        Me.NUD_IDNumber.Location = New System.Drawing.Point(111, 47)
        Me.NUD_IDNumber.Name = "NUD_IDNumber"
        Me.NUD_IDNumber.Size = New System.Drawing.Size(189, 20)
        Me.NUD_IDNumber.TabIndex = 12
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(348, 250)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cbx_Gender)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbx_Surname)
        Me.Controls.Add(Me.tbx_Forename)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NUD_Age)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.NUD_IDNumber)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.NUD_Age, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_IDNumber, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_Clear As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents cbx_Gender As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents tbx_Surname As TextBox
    Friend WithEvents tbx_Forename As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents NUD_Age As NumericUpDown
    Friend WithEvents Label1 As Label
    Friend WithEvents NUD_IDNumber As NumericUpDown
End Class
